# plugin.program.iptv-list_refresh
Kodi addon to refresh an online m3u run a filter and save it as a new local m3u-file.

We got a simple settings page, asking for url, filtering words, user agent for download and local storage path/filename.
Filter alternative could be expanded, right now only category (channel groups).

A lot of credits should go to bmillham.
